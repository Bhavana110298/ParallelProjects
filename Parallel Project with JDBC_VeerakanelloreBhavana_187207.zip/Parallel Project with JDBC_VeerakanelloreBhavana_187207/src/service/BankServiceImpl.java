package service;

import java.sql.SQLException;

import bean.BankBean;
import bean.BankTransaction;
import dao.BankDaoImpl;
import dao.BankDao;
import exceptions.*;

public class BankServiceImpl implements BankService {

	BankDao dao = (BankDao) new BankDaoImpl();
	BankBean bank = new BankBean();
	BankBean bank1 = new BankBean();

	boolean result;

	// to get the details if account exists or not and add account

	public boolean createAccount(String name, String address, long accNum, String phone, int pin, int balance)
			throws AccountAlreadyExistsException, ClassNotFoundException, SQLException {

		BankBean bean = new BankBean();
		boolean res = false;
		res = dao.checkAccount(accNum);

		if (res) {
			bean.setAccNo(accNum);
			bean.setAdd(address);
			bean.setBalance(balance);
			bean.setName(name);
			bean.setPhone(phone);
			bean.setPin(pin);
			bean.setTrans("Account Created with Balance  : " + balance + "\n");

			dao.InsertData(accNum, bean);

			result = true;
		}

		else

		{
			res = false;
			throw new AccountAlreadyExistsException();
		}
		return result;

	}

	// to show balance

	public int showBalance(long accNo) throws AccountNotFoundException, ClassNotFoundException, SQLException {

		try {
			result = dao.checkAccount(accNo);
		}

		catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}

		int balance = 0;

		if (result) {
			throw new AccountNotFoundException();
		} else {
			bank = dao.getAccountDetails(accNo);
			balance = bank.getBalance();
		}

		return balance;
	}

	// to deposit

	public int deposit(long accNum, int deposit_amount)
			throws AccountNotFoundException, ClassNotFoundException, SQLException {

		int balance = 0;
		try {
			result = dao.checkAccount(accNum);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}

		if (result) {
			throw new AccountNotFoundException();
		} else {
			bank = dao.getAccountDetails(accNum);
		}
		if (bank == null) {
			throw new AccountNotFoundException();
		} else {

			balance = bank.setBalance(bank.getBalance() + deposit_amount);
			String s = bank.getTrans() + "Amount deposited :" + deposit_amount + "\n";
			bank.setTrans(s);
			// dao.InsertData(accNo,bank);
			dao.updateData(bank);
		}

		return balance;
	}

	// to withdraw

	public int withdraw(long accNum, int withdraw_amount)
			throws AccountNotFoundException, LowBalanceException, ClassNotFoundException, SQLException {

		int balance = 0;
		try {
			result = dao.checkAccount(accNum);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}
		if (result) {
			throw new AccountNotFoundException();
		} else {
			bank = dao.getAccountDetails(accNum);
			if (bank == null) {
				throw new AccountNotFoundException();
			}
			if (bank.getBalance() > withdraw_amount) {
				balance = bank.setBalance(bank.getBalance() - withdraw_amount);
				String s = bank.getTrans() + "Amount withdrawn :" + withdraw_amount + "\n";
				bank.setTrans(s);
			} else {
				throw new LowBalanceException();
			}
			// dao.InsertData(accNo, bank);
			dao.updateData(bank);
		}

		return balance;
	}

	// to transfer fund

	public boolean transferfund(long accNum, long accNum1, int transfer_amount)
			throws AccountNotFoundException, LowBalanceException, ClassNotFoundException, SQLException {

		result = dao.checkAccount(accNum);
		if (result) {
			throw new AccountNotFoundException();
		} else {
			bank = dao.getAccountDetails(accNum);
			int balance = bank.getBalance();
			result = validateBalance(accNum, transfer_amount);
			if (result) {
				result = dao.checkAccount(accNum1);
				if (result) {
					throw new AccountNotFoundException();
				} else {
					bank1 = dao.getAccountDetails(accNum1);
					int balance1 = bank1.getBalance();
					bank.setBalance(balance - transfer_amount);
					bank1.setBalance(balance1 + transfer_amount);
					dao.updateData(bank);
					dao.updateData(bank1);
				}
			} else {
				throw new LowBalanceException();

			}
		}
		return true;
	}

	// to validateBalance

	public boolean validateBalance(long accNum, int amount)
			throws LowBalanceException, AccountNotFoundException, ClassNotFoundException, SQLException

	{

		result = dao.checkAccount(accNum);
		if (result) {
			throw new AccountNotFoundException();
		} else {
			bank = dao.getAccountDetails(accNum);
			int balance = bank.getBalance();
			if (balance < amount) {
				throw new LowBalanceException();
			} else {
				return true;
			}
		}
	}

	// to set transactions

	public String setTrans(long accNum) throws AccountNotFoundException {

		try {
			result = dao.checkAccount(accNum);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}
		String s;

		if (bank == null) {
			throw new AccountNotFoundException();
		} else {
			s = bank.getTrans();
		}
		return s;
	}

	@Override
	public void setTransactions(BankTransaction transaction) throws ClassNotFoundException, SQLException {

		dao.setTransactions(transaction);
	}

	@Override
	public BankTransaction getTransactions(long accNum) throws ClassNotFoundException, SQLException {
		BankTransaction transaction = new BankTransaction();
		transaction = dao.getTransactions(accNum);
		return transaction;
	}
}
