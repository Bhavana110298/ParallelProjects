package com.cg.bank.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.bank.entities.BankEntity;

@Repository
public interface BankEntityDao extends JpaRepository<BankEntity, Long> {

	@Query("select accNum,pswd,name,address from BankEntity where accNum =?1")
	Optional<BankEntity> accountsDetails(@Param("c") Long accNum);

	@Query("select be.balance from BankEntity be where be.accNum =?1")
	Optional<Double> showBalance(@Param("c") Long accNum);
}