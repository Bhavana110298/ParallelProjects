package com.cg.bank.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
@Table(name="BankEntity")
@Entity
public class BankEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "acc")
	@SequenceGenerator(name = "acc", sequenceName = "account")
	@Column(length = 15)
	private Long accNum;
	@Min(4)
	@Max(20)
	@Column(length = 15)
	private String pswd;
	@Min(4)
	@Max(20)
	@Column(length = 15)
	private String name;
	@Min(4)
	@Max(20)
	@Column(length = 15)
	private String address;
	@Column(length = 20)
	private Double balance;
	@Min(10)
	@Max(11)
	@Column(length = 10)
	private String mobNum;

	public BankEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public BankEntity(Long accNum, @Min(4) @Max(20) String pswd, @Min(4) @Max(20) String name,
			@Min(4) @Max(20) String address, Double balance, @Min(10) @Max(11) String mobNum) {
		super();
		this.accNum = accNum;
		this.pswd = pswd;
		this.name = name;
		this.address = address;
		this.balance = balance;
		this.mobNum = mobNum;
	}



	public Long getAccNum() {
		return accNum;
	}

	public void setAccNum(Long accNum) {
		this.accNum = accNum;
	}

	public String getPswd() {
		return pswd;
	}

	public void setPswd(String pswd) {
		this.pswd = pswd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public String getMobNum() {
		return mobNum;
	}

	public void setMobNum(String mobNum) {
		this.mobNum = mobNum;
	}

	@Override
	public String toString() {
		return "BankEntity [accNum=" + accNum + ", pswd=" + pswd + ", name=" + name + ", address=" + address
				+ ", balance=" + balance + ", mobNum=" + mobNum + "]";
	}

}

