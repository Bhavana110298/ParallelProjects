package com.cg.bank.exception;

public class BankException {
	String msg;
	public BankException()
	{
		super();
	}
	public BankException(String msg)
	{
		this.msg=msg;
	}
}
