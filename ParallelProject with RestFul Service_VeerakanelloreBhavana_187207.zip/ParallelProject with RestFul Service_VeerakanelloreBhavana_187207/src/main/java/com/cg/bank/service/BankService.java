package com.cg.bank.service;

import java.util.List;

import com.cg.bank.entities.TransactionEntity;
import com.cg.bank.exception.BankException;

public interface BankService {
	public BankEntity createAccount(BankEntity bank) throws BankException;
	public BankEntity accountsDetails(Long accNum) throws BankException;
	public Double showBalance(Long accNum) throws BankException;
	public Double deposit(Long accNum, Double amount) throws BankException;
	public Double withDraw(Long accNum, Double amount) throws BankException;
	public Double fundTransfer(Long accNum1, Double amount, Long accNum2) throws BankException;
	public List<TransactionEntity> printTransaction(Long accNum) throws BankException;
}
