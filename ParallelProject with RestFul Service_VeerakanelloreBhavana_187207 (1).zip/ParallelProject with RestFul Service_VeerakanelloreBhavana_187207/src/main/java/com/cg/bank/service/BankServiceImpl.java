package com.cg.bank.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.exception.BankException;
import com.cg.bank.dao.BankEntityDao;
import com.cg.bank.dao.TransactionEntityDao;
import com.cg.bank.entities.BankEntity;
import com.cg.bank.entities.TransactionEntity;

@Service
public class BankServiceImpl implements BankService {

	@Autowired
	BankEntityDao bankEntityDao;

	@Autowired
	TransactionEntityDao transactionEntityDao;

	public BankEntity createAccount(BankEntity bank) throws BankException {
		if(bank.getBalance()==null || bank.getBalance()<=0){
			throw new BankException("Balance can not be 0");
		}else {
			bankEntityDao.save(bank);
			return bankEntityDao.findById(bank.getAccNum()).get();
		}
	}

	public BankEntity accountsDetails(Long accNum) throws BankException {
		if(!bankEntityDao.findById(accNum).isPresent()) {
			throw new BankException("Sorry, Account number does not exist\nPlease enter a valid Account number.");
		}else{
			return bankEntityDao.findById(accNum).get();
		}
	}

	public Double showBalance(Long accNum) throws BankException {
		if(!bankEntityDao.findById(accNum).isPresent()) {
			throw new BankException("Sorry, Account number does not exist\nPlease enter a valid Account number.");
		}else{
			return  bankEntityDao.findById(accNum).get().getBalance();
		}

	}

	public Double deposit(Long accNum, Double amount) throws BankException {

		Optional<BankEntity> bank = bankEntityDao.findById(accNum);
		if (bank.isPresent()) {
			BankEntity tempEntity = bank.get();
			tempEntity.setBalance(bank.get().getBalance() + amount);
			bankEntityDao.save(tempEntity);
			
			 TransactionEntity trans = new TransactionEntity(accNum, "Deposite",
			  bank.get().getBalance(), bank.get().getBalance() + amount);
			  transactionEntityDao.save(trans);
			 
			return showBalance(accNum);
		} else {
			throw new BankException("Sorry, Account number does not exist\nPlease enter a valid Account number.");
		}
	}

	public Double withDraw(Long accNum, Double amount) throws BankException {
		Optional<BankEntity> bank = bankEntityDao.findById(accNum);
		if (bank.isPresent()) {
			if(amount>showBalance(accNum)) {
				throw new BankException("Insufficient Balance :-(");
			}else {
				BankEntity tempEntity = bank.get();
				tempEntity.setBalance(bank.get().getBalance() - amount);
				bankEntityDao.save(tempEntity);
				TransactionEntity trans = new TransactionEntity(accNum, "Withdraw", bank.get().getBalance(),bank.get().getBalance() - amount);
				transactionEntityDao.save(trans);
				return showBalance(accNum);	
			}
		} else {
			throw new BankException("Sorry, Account number does not exist\nPlease enter a valid Account number.");
		}
	}

	public Double fundTransfer(Long senderAcc, Double amount, Long reciverAcc) throws BankException {
		Optional<BankEntity> senderAccount = bankEntityDao.findById(senderAcc);
		Optional<BankEntity> reciverAccount = bankEntityDao.findById(reciverAcc);
		if (senderAccount.isPresent() && reciverAccount.isPresent()) {

			BankEntity sender = senderAccount.get();
			sender.setBalance(senderAccount.get().getBalance() - amount);
			bankEntityDao.save(sender);

			BankEntity reciver = reciverAccount.get();
			reciver.setBalance(reciverAccount.get().getBalance() + amount);
			bankEntityDao.save(reciver);

			TransactionEntity senderTrans = new TransactionEntity(senderAcc, "Fund Transfer", senderAccount.get().getBalance(),senderAccount.get().getBalance() - amount);
			transactionEntityDao.save(senderTrans);

			TransactionEntity reciverTrans = new TransactionEntity(reciverAcc, "Fund Recieved", reciverAccount.get().getBalance(),amount + reciverAccount.get().getBalance());
			transactionEntityDao.save(reciverTrans);

			return showBalance(senderAcc);
		} else {
			throw new BankException("Sorry, Account number does not exist\nPlease enter a valid Account number.");
		}
	}

	public List<TransactionEntity> printTransaction(Long accNum) throws BankException {
		if(!bankEntityDao.findById(accNum).isPresent()) {
			throw new BankException("Sorry, Account number does not exist\nPlease enter a valid Account number.");
		}else{
			return transactionEntityDao.printTransaction(accNum);
		}
	}

}
