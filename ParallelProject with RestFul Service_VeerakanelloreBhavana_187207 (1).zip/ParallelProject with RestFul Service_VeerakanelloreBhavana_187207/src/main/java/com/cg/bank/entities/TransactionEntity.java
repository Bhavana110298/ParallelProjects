package com.cg.bank.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="TransactionEntity")
public class TransactionEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "acc")
	@SequenceGenerator(name = "acc", sequenceName = "transactionSeq")
	@Column(length = 20)
	private Integer transNum;
	@Column(length = 20)
	private Long accnum;
	@Column(length = 20)
	private String transType;
	@Column(length = 20)
	private Double previousBal;
	@Column(length = 20)
	private Double currentBal;
	public TransactionEntity(Long accnum, String transType, Double previousBal, Double currentBal) {
		super();
		this.accnum = accnum;
		this.transType = transType;
		this.previousBal = previousBal;
		this.currentBal = currentBal;
	}
	public TransactionEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getTransNum() {
		return transNum;
	}
	public void setTransNum(Integer transNum) {
		this.transNum = transNum;
	}
	public Long getAccnum() {
		return accnum;
	}
	public void setAccnum(Long accnum) {
		this.accnum = accnum;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public Double getPreviousBal() {
		return previousBal;
	}
	public void setPreviousBal(Double previousBal) {
		this.previousBal = previousBal;
	}
	public Double getCurrentBal() {
		return currentBal;
	}
	public void setCurrentBal(Double currentBal) {
		this.currentBal = currentBal;
	}
	@Override
	public String toString() {
		return "TransactionEntity [transNum=" + transNum + ", accnum=" + accnum + ", transType=" + transType
				+ ", previousBal=" + previousBal + ", currentBal=" + currentBal + "]";
	}
	
	
	}
