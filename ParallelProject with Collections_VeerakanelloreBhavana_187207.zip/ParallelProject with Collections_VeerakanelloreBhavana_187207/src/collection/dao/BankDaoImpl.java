package collection.dao;

import java.util.HashMap;

import collection.bean.BankBean;
import collection.exceptions.AccountNotFoundException;
import collection.exceptions.LowBalanceException;

public class BankDaoImpl implements BankDao {

	HashMap h1;

	public BankDaoImpl() {

		h1 = new HashMap();
	}

	// bean class object

	BankBean bean = new BankBean();

	// to check account already exists or not

	public BankBean checkAccount(long accNum) {

		if (h1.containsKey(accNum)) {

			bean = (BankBean) h1.get(accNum);
			return bean;

		} else

			return null;
	}

	// to put the data into the map

	public void setData(long accNum, BankBean bean) {

		h1.put(accNum, bean);
	}

}
