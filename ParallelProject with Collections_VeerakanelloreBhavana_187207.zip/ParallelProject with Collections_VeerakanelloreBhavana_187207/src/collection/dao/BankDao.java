package collection.dao;

import collection.bean.BankBean;

public interface BankDao {

	public BankBean checkAccount(long accNum);

	public void setData(long accNum, BankBean bean);

}
