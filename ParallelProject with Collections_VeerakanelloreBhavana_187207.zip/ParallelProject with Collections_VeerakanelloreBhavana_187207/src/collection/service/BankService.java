package collection.service;

import collection.exceptions.AccountAlreadyExistsException;
import collection.exceptions.AccountNotFoundException;
import collection.exceptions.LowBalanceException;

public interface BankService {

	public boolean createAccount(String name, String address, long accNum, String phone, int pin, int balance)
			throws AccountAlreadyExistsException;

	public int showBalance(long accNum) throws AccountNotFoundException;

	public int deposit(long accNum, int deposit_amount) throws AccountNotFoundException;

	public int withdraw(long accNum, int withdraw_amount) throws AccountNotFoundException, LowBalanceException;

	public boolean transferfund(long accNum, long accNum1, int transfer_amount)
			throws AccountNotFoundException, LowBalanceException;

	public boolean validateBalance(long accNum, int amount) throws LowBalanceException;

	public String setTrans(long accNum) throws AccountNotFoundException;

}
