package collection.service;

import collection.bean.BankBean;
import collection.dao.BankDao;
import collection.dao.BankDaoImpl;
import collection.exceptions.*;

public class BankServiceImpl implements BankService {

	BankDao dao = new BankDaoImpl();
	BankBean bank = new BankBean();
	BankBean bank1 = new BankBean();

	boolean res;

	// to get the details if account exists or not and add account

	public boolean createAccount(String name, String address, long accNum, String phone, int pin, int balance)
			throws AccountAlreadyExistsException {

		BankBean bean = new BankBean();
		boolean res = false;

		if (dao.checkAccount(accNum) == null) {

			bean.setAccNo(accNum);
			bean.setAdd(address);
			bean.setBalance(balance);
			bean.setName(name);
			bean.setPhone(phone);
			bean.setPin(pin);
			bean.setTrans("Account Created with Balance  : " + balance + "\n");

			dao.setData(accNum, bean);

			res = true;
		}

		else

		{
			res = false;
			throw new AccountAlreadyExistsException();
		}
		return res;

	}

	// to show balance

	public int showBalance(long accNum) throws AccountNotFoundException {

		bank = dao.checkAccount(accNum);
		int balance = 0;
		if (bank == null) {
			throw new AccountNotFoundException();
		} else {
			balance = bank.getBalance();
		}

		return balance;
	}

	// to deposit

	public int deposit(long accNum, int deposit_amount) throws AccountNotFoundException {

		int balance = 0;
		bank = dao.checkAccount(accNum);

		if (bank == null) {
			throw new AccountNotFoundException();
		} else {

			balance = bank.setBalance(bank.getBalance() + deposit_amount);
			String s = bank.getTrans() + "Amount deposited :" + deposit_amount + "\n";
			bank.setTrans(s);
			dao.setData(accNum, bank);
		}

		return balance;
	}

	// to withdraw

	public int withdraw(long accNum, int withdraw_amount) throws AccountNotFoundException, LowBalanceException {

		int balance = 0;
		bank = dao.checkAccount(accNum);
		if (bank == null) {
			throw new AccountNotFoundException();
		} else {
			if (bank.getBalance() > withdraw_amount) {
				balance = bank.setBalance(bank.getBalance() - withdraw_amount);
				String s = bank.getTrans() + "Amount withdrawn :" + withdraw_amount + "\n";
				bank.setTrans(s);
			} else {
				throw new LowBalanceException();
			}
			dao.setData(accNum, bank);
		}

		return balance;
	}

	// to transfer fund

	public boolean transferfund(long accNum, long accNum1, int transfer_amount)
			throws AccountNotFoundException, LowBalanceException {

		bank = dao.checkAccount(accNum);

		if (!(bank == null)) {

			bank1 = dao.checkAccount(accNum1);

			if (!(bank1 == null))

			{

				int sender_balance = bank.getBalance();

				if (sender_balance > transfer_amount) {
					int reciever_balance = bank1.getBalance();

					bank.setBalance(sender_balance - transfer_amount);
					bank1.setBalance(reciever_balance + transfer_amount);
					String s = bank.getTrans() + "Transferred to  :" + accNum1 + " Amount : " + transfer_amount + "\n";
					bank.setTrans(s);
					String s1 = bank1.getTrans() + "Transferred from  :" + accNum + " Amount : " + transfer_amount
							+ "\n";
					bank1.setTrans(s1);
					dao.setData(accNum, bank);
					dao.setData(accNum1, bank1);
				} else {
					throw new LowBalanceException();
				}
			}

			else {
				throw new AccountNotFoundException();
			}
		} else {
			throw new AccountNotFoundException();
		}

		return true;
	}

	// to validateBalance

	public boolean validateBalance(long accNum, int amount) throws LowBalanceException

	{
		bank = dao.checkAccount(accNum);
		if (bank == null) {
			throw new LowBalanceException();
		} else {
			return true;
		}
	}

	// to set transactions

	public String setTrans(long accNum) throws AccountNotFoundException {

		bank = dao.checkAccount(accNum);
		String s;

		if (bank == null) {
			throw new AccountNotFoundException();
		} else {
			s = bank.getTrans();
		}
		return s;
	}

}
