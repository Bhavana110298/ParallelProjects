package com.cg.bank.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bank.bean.Transaction;
import com.cg.bank.dao.BankTransactionDao;
@Service
public class BankTranscationServiceImpl implements BankTransactionService {
    @Autowired
	 BankTransactionDao bankTransactionDao;
	@Override
	public void addTransaction(String message, int number) {
	      int id = (int) Math.ceil((Math.random()*1000));
          Transaction tran = new Transaction(id, number, message);
          bankTransactionDao.save(tran);
	}

	@Override
	public List<String> getTransaction(int id) {
        List<Transaction> ls = bankTransactionDao.findAll();
        List<String> listShow = new ArrayList<String>();
        for(Transaction t: ls) {
            if(t.getNumber() == id) {
                listShow.add(t.getId());
            }
        }
        return listShow;
	}

}
