package com.cg.bank.service;

import java.util.List;

public interface BankTransactionService {
	   void addTransaction(String message, int number);
	    List<String> getTransaction(int id);

}
