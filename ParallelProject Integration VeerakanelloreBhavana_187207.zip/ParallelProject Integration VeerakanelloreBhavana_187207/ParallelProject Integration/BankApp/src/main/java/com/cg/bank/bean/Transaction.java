package com.cg.bank.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "transaction")
@Entity
public class Transaction {
	    @Id
	    @GeneratedValue
	    int id;
	    int number;
	    String message;
		public Transaction(int id, int number, String message) {
			super();
			this.id = id;
			this.number = number;
			this.message = message;
		}
		public Transaction() {
			super();
			// TODO Auto-generated constructor stub
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public int getNumber() {
			return number;
		}
		public void setNumber(int number) {
			this.number = number;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		@Override
		public String toString() {
			return "Transaction [id=" + id + ", number=" + number + ", message=" + message + "]";
		}
	    
	   
}
