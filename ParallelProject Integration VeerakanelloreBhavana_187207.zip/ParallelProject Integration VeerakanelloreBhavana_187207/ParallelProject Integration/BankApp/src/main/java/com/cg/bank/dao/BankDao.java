package com.cg.bank.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.bank.bean.Customer;
@Repository
public interface BankDao extends JpaRepository<Customer, Integer> {
	 @Query("from Customer where accountNo=:accno")
	 	Customer getCustomerByAccountNo(@Param("accno") int accountNo);

	     
	     @Query("from Customer where username=:un")
	     Customer getCustomerByUsername(@Param("un") String username);

}
